# Results Pack finaltwo

- Generated: 2025-10-16T16:26:20
- Equity window: 2024-01-01T00:00:00 → 2024-12-31T00:00:00
- Final candidates: 2

## Missing Artefacts
- results\run_meta_finaltwo.json

## Final Candidates
| set_id | pf_ext | avg_ret_ext | maxDD_ext | pf_drift_ext | dd_change_ext | accepted |
|---|---|---|---|---|---|---|
| 2 | 0.00 | -1.01% | 1.01% | -1.31 | -14.99 | NO |
| 1 | 0.57 | -0.29% | 0.67% | -0.70 | -17.33 | NO |

## Files Included
- equity_1_2024-01-01_2024-12-31.csv
- equity_2_2024-01-01_2024-12-31.csv
- final_candidates_finaltwo.csv
- metrics_1_2024-01-01_2024-12-31.json
- metrics_2_2024-01-01_2024-12-31.json
- wf_stability_ext_summary_finaltwo.csv
